
## WeatherPy



```python
# import dependencies
import json
import requests
from config import api_key
!pip install citipy
```

    Requirement already satisfied: citipy in c:\users\emma\anaconda3\lib\site-packages
    Requirement already satisfied: kdtree>=0.12 in c:\users\emma\anaconda3\lib\site-packages (from citipy)
    

    You are using pip version 9.0.1, however version 10.0.1 is available.
    You should consider upgrading via the 'python -m pip install --upgrade pip' command.
    


```python
# generate random latitude and longitude
from random import uniform
import numpy as np
from citipy import citipy

cities = []
counter = 0

for i in range(1100):
    y = uniform(-180,180)
    x = uniform(-90, 90)
    city = citipy.nearest_city(x,y)
    city = city.city_name

    if city not in cities:
        cities.append(city)
        
        counter += 1
print(len(cities))
```

    511
    


```python
cities = list(set(cities))
len(cities)
```




    511




```python
# look at data
city = cities[0]
print(city)
url = "http://api.openweathermap.org/data/2.5/weather?"
units = 'imperial'
query_url = url + "appid=" + api_key + "&q=" + city +  "&units=" + units
print(query_url)
weather_response = requests.get(query_url)
weather_json = weather_response.json()
print(f"The weather API responded with: {json.dumps(weather_json, indent=2)}.")

```

    somerset
    http://api.openweathermap.org/data/2.5/weather?appid=25bc90a1196e6f153eece0bc0b0fc9eb&q=somerset&units=imperial
    The weather API responded with: {
      "coord": {
        "lon": -84.6,
        "lat": 37.09
      },
      "weather": [
        {
          "id": 800,
          "main": "Clear",
          "description": "clear sky",
          "icon": "01n"
        }
      ],
      "base": "stations",
      "main": {
        "temp": 58.53,
        "pressure": 1016,
        "humidity": 77,
        "temp_min": 55.4,
        "temp_max": 60.8
      },
      "visibility": 16093,
      "wind": {
        "speed": 2.86,
        "deg": 57
      },
      "clouds": {
        "all": 1
      },
      "dt": 1528347360,
      "sys": {
        "type": 1,
        "id": 1153,
        "message": 0.004,
        "country": "US",
        "sunrise": 1528366706,
        "sunset": 1528419389
      },
      "id": 4308922,
      "name": "Somerset",
      "cod": 200
    }.
    


```python
print(
    weather_json['main']['temp'],
    weather_json['coord']['lat'],
    weather_json['main']['humidity'],
    weather_json['clouds']['all'],
    weather_json['wind']['speed'],
    weather_json['id']
)
```

    58.53 37.09 77 1 2.86 4308922
    


```python
# gather info 
url = "http://api.openweathermap.org/data/2.5/weather?"
units = 'Imperial'
temp = []
name = []
humidity = []
lat = []
cloudiness = []
wind_speed = []
city_id = []
for city in cities:
    query_url = url + "appid=" + api_key + "&q=" + city +  "&units=" + units
    response = requests.get(query_url)
    weather_json = response.json()
    
    try:
        temp.append(weather_json['main']['temp'])
        humidity.append(weather_json['main']['humidity'])
        lat.append(weather_json['coord']['lat'])
        cloudiness.append(weather_json['clouds']['all'])
        wind_speed.append(weather_json['wind']['speed'])
        name.append(weather_json['name'])
        city_id.append(weather_json['id'])
    except KeyError:
        temp = temp
        humidity = humidity
        lat = lat
        cloudiness = cloudiness
        wind_speed = wind_speed
        city_id = city_id
    
    
    
    
```


```python
# print(temp)
len(temp)
```




    460




```python
data = {
    'Name': name,
    'Latitude': lat,
    'Temperature': temp,
    'Humidity': humidity,
    'Cloudiness': cloudiness,
    'Wind Speed': wind_speed
}

```


```python
import pandas as pd
weather_df = pd.DataFrame(
    data
)

```


```python
weather_df.head()
weather_df = weather_df.set_index('Name')
```


```python
weather_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Cloudiness</th>
      <th>Humidity</th>
      <th>Latitude</th>
      <th>Temperature</th>
      <th>Wind Speed</th>
    </tr>
    <tr>
      <th>Name</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Somerset</th>
      <td>1</td>
      <td>77</td>
      <td>37.09</td>
      <td>58.53</td>
      <td>2.86</td>
    </tr>
    <tr>
      <th>Sistranda</th>
      <td>75</td>
      <td>93</td>
      <td>63.73</td>
      <td>48.20</td>
      <td>19.46</td>
    </tr>
    <tr>
      <th>Te Anau</th>
      <td>64</td>
      <td>96</td>
      <td>-45.41</td>
      <td>35.87</td>
      <td>1.81</td>
    </tr>
    <tr>
      <th>Lorengau</th>
      <td>36</td>
      <td>100</td>
      <td>-2.02</td>
      <td>81.05</td>
      <td>4.99</td>
    </tr>
    <tr>
      <th>Teguldet</th>
      <td>44</td>
      <td>54</td>
      <td>57.31</td>
      <td>76.55</td>
      <td>3.53</td>
    </tr>
  </tbody>
</table>
</div>




```python

weather_df.to_csv('weather_data.csv')
```


```python
import matplotlib.pyplot as plt
```


```python
# temp vs lat

plt.scatter(weather_df['Latitude'], weather_df['Temperature'], color='yellow')
plt.xlabel('Latitude')
plt.ylabel('Temperature (F)')
plt.title('Temperature v Latitude (06 June 2018)')
plt.savefig('temp_v_lat.png', bbox_inches='tight')
```


![png](output_14_0.png)



```python
# humidity vs lat
plt.scatter(weather_df['Latitude'], weather_df['Humidity'], color='blue')
plt.xlabel('Latitude')
plt.ylabel('Temperature (F)')
plt.title('Humidity v Latitude (06 June 2018)')
plt.savefig('humidity_v_lat.png', bbox_inches='tight')
```


![png](output_15_0.png)



```python
# cloudiness vs lat
plt.scatter(weather_df['Latitude'], weather_df['Cloudiness'], color='orange')
plt.xlabel('Latitude')
plt.ylabel('Cloudiness (%)')
plt.title('Cloudiness v Latitude (06 June 2018)')
plt.savefig('cloudiness_v_lat.png', bbox_inches='tight')
```


![png](output_16_0.png)



```python
# wind speed vs lat
plt.scatter(weather_df['Latitude'], weather_df['Wind Speed'], color='green')
plt.xlabel('Latitude')
plt.ylabel('Wind Speed (MPH)')
plt.title('Wind Speed v Latitude (06 June 2018)')
plt.savefig('wind_v_lat.png', bbox_inches='tight')
```


![png](output_17_0.png)

